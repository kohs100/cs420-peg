use std::ops;

use super::defs::ATyp::*;
use super::defs::Typ::*;
use super::defs::{ATyp, ITyp, Typ};

// Implicit conversion between arithmetic types
// https://en.cppreference.com/w/cpp/language/implicit_conversion
// https://en.cppreference.com/w/cpp/language/array#Array-to-pointer_decay
pub trait ImplicitConversion<T> {
    fn becomes(&self, rhs: T) -> bool;
}

impl ImplicitConversion<&Typ> for Typ {
    fn becomes(&self, rhs: &Typ) -> bool {
        let lhs = self;
        if lhs == rhs {
            return true;
        }
        match (lhs, rhs) {
            (Array(srctyp, _), Address(tgttyp)) => {
                // Handle array-to-pointer decay.
                // decay is applied only once for multidimensional array.
                srctyp == tgttyp
            }
            (Arith(at1), Arith(at2)) => at1.becomes(at2),
            (Address(_), Address(should_void)) => {
                // Pointer conversions
                // Implicit conversion into void pointer
                should_void.as_ref() == &Void
            }
            (lhs @ FuncDecl(_, _), Address(btyp)) => {
                // Function-to-pointer conversion
                match btyp.as_ref() {
                    rhs @ FuncDecl(_, _) => lhs == rhs,
                    _ => false,
                }
            }
            (lhs, Arith(Bool)) => {
                // Boolean conversions.
                lhs != &Void
            }
            _ => false,
        }
    }
}

impl ImplicitConversion<&ATyp> for ATyp {
    fn becomes(&self, _rhs: &ATyp) -> bool {
        // Implicit conversion between integers is always possible by
        // finite sequence of integral promotion and conversion

        // Implicit conversion between floats is always possible by
        // finite sequence of floating-point promotion and conversion

        // Floating-integral conversions.

        // Boolean conversions.

        // Implicit conversions between arithmetic types are always possible.
        true
    }
}

impl ImplicitConversion<ATyp> for Typ {
    fn becomes(&self, rhs: ATyp) -> bool {
        self.becomes(&Arith(rhs))
    }
}

// Perform usual arithmetic conversion.
// https://en.cppreference.com/w/cpp/language/usual_arithmetic_conversions
impl ops::Add<ATyp> for ATyp {
    type Output = ATyp;
    fn add(self, rhs: ATyp) -> Self::Output {
        let lhs = self.promote();
        let rhs = rhs.promote();

        match (lhs, rhs) {
            (it @ (Float(_) | Int(_)), ft @ Float(fb)) | (ft @ Float(fb), it @ Int(_)) => {
                // If either operand is of floating-point type, ...
                if let Float(ib) = it {
                    if ib.width_bytes() > fb.width_bytes() {
                        it
                    } else {
                        ft
                    }
                } else {
                    ft
                }
            }
            (lt @ Int(lityp), rt @ Int(rityp)) => {
                if lityp.signed() == rityp.signed() {
                    // If T1 and T2 are both signed integer types or both unsigned
                    // integer types, C is the type of greater integer conversion
                    // rank.
                    if lityp.width_bytes() > rityp.width_bytes() {
                        lt
                    } else {
                        rt
                    }
                } else {
                    // Otherwise, one type between T1 and T2 is an signed integer
                    // type S, the other type is an unsigned integer type U.
                    // Apply the following rules:

                    // If the integer conversion rank of U is greater than or
                    // equal to the integer conversion rank of S, C is U.
                    let (st, ut, sityp, uityp) = if lityp.signed() {
                        (lt, rt, lityp, rityp)
                    } else {
                        (rt, lt, rityp, lityp)
                    };
                    let sb = sityp.width_bytes();
                    let ub = uityp.width_bytes();
                    if ub >= sb {
                        ut
                    }
                    // Otherwise, if S can represent all of the values of U, C is S.
                    else if sb >= ub * 2 {
                        st
                    }
                    // Otherwise, C is the unsigned integer type corresponding to S.
                    else {
                        sityp.as_unsigned().into()
                    }
                }
            }
            (Bool, _) | (_, Bool) => {
                unreachable!("atyp cannot be bool after arithmetic promotion")
            }
        }
    }
}
