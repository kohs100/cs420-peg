pub mod casting;
pub mod check;
pub mod check_expr;
pub mod defs;
pub mod scope;

use std::fmt::Debug;
use std::fmt::Display;

use crate::ast::expr::Position;
use crate::ast::expr::Stmt;
use crate::ast::types::Declaration;
use defs::Typ;

pub type TypeResult<T> = Result<T, PositionalTypeError>;

#[derive(Debug, Clone)]
pub enum ErrorLocation {
    Stmt(Stmt),
    Decl(Declaration),
}
impl ErrorLocation {
    pub fn get_position(&self) -> Position {
        match self {
            Self::Stmt(stmt) => stmt.get_position().clone(),
            Self::Decl(Declaration(_, _, pos)) => pos.clone(),
        }
    }
}
impl Display for ErrorLocation {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Stmt(stmt) => write!(f, "{}", stmt),
            Self::Decl(decl) => write!(f, "{}", decl),
        }
    }
}

#[derive(Debug, Clone)]
pub struct PositionalTypeError {
    err: TypeError,
    at: Vec<ErrorLocation>,
}
impl From<TypeError> for PositionalTypeError {
    fn from(value: TypeError) -> Self {
        Self {
            err: value,
            at: Vec::new(),
        }
    }
}
pub trait AddPosition<T> {
    fn at(&mut self, pos: T);
}
impl AddPosition<Stmt> for PositionalTypeError {
    fn at(&mut self, pos: Stmt) {
        self.at.push(ErrorLocation::Stmt(pos));
    }
}
impl AddPosition<Declaration> for PositionalTypeError {
    fn at(&mut self, pos: Declaration) {
        self.at.push(ErrorLocation::Decl(pos));
    }
}

impl Display for PositionalTypeError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if let Some(pos) = self.at.get(0) {
            write!(f, "{}\n  Occured at >> {} <<", self.err, pos)
        } else {
            write!(f, "{}", self.err)
        }
    }
}

#[derive(Debug, Clone)]
pub enum TypeError {
    InvalidIdentifier(String),
    InvalidDefinition(String),
    Redefinition(String),
    TypeMismatch(String, Typ, Typ),
    TypesMismatch(String, Vec<Typ>, Vec<Typ>),
    TypeIncompatible,
    NotBool(Typ),
    NotCallable(Typ),
}
impl Display for TypeError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidIdentifier(i) => {
                write!(f, "Invalid identifier: {}", i)
            }
            Self::InvalidDefinition(i) => {
                write!(f, "Invalid type definition: {}", i)
            }
            Self::Redefinition(i) => {
                write!(f, "Invalid redefinition of identifier: {}", i)
            }
            Self::TypeMismatch(i, lt, rt) => {
                write!(f, "Type mismatch: {}: {} vs {}", i, lt, rt)
            }
            Self::TypesMismatch(i, lts, rts) => {
                write!(f, "Types mismatch: {}: [", i)?;
                for lt in lts {
                    write!(f, "{},", lt)?;
                }
                write!(f, "] vs [")?;
                for rt in rts {
                    write!(f, "{}, ", rt)?;
                }
                write!(f, "]")
            }
            Self::TypeIncompatible => {
                write!(f, "Type incompatible")
            }
            Self::NotBool(typ) => {
                write!(f, "Cannot be bool: {}", typ)
            }
            Self::NotCallable(typ) => {
                write!(f, "Cannot be callsed: {}", typ)
            }
        }
    }
}
