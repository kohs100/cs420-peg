use std::ops;

use crate::types::defs::{ATyp, Typ};

// 64-bit address width as byte
pub const ADDR_WIDTH: usize = 8;
type ADDR_TYPE = u64;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct VirtualPointer(ADDR_TYPE);
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct VirtualPointerDelta(ADDR_TYPE);

impl ops::Sub<VirtualPointer> for VirtualPointer {
    type Output = VirtualPointerDelta;
    fn sub(self, rhs: VirtualPointer) -> Self::Output {
        let Self(lptr) = self;
        let Self(rptr) = rhs;
        assert!(lptr > rptr);
        VirtualPointerDelta(lptr - rptr)
    }
}

impl ops::Add<VirtualPointerDelta> for VirtualPointer {
    type Output = VirtualPointer;
    fn add(self, rhs: VirtualPointerDelta) -> Self::Output {
        let Self(lptr) = self;
        let VirtualPointerDelta(delta) = rhs;
        VirtualPointer(lptr + delta)
    }
}

impl ops::Add<VirtualPointerDelta> for VirtualPointerDelta {
    type Output = VirtualPointerDelta;
    fn add(self, rhs: VirtualPointerDelta) -> Self::Output {
        let Self(ldelta) = self;
        let VirtualPointerDelta(rdelta) = rhs;
        VirtualPointerDelta(ldelta + rdelta)
    }
}

impl ops::AddAssign<VirtualPointerDelta> for VirtualPointerDelta {
    fn add_assign(&mut self, rhs: VirtualPointerDelta) {
        *self = *self + rhs;
    }
}

impl ops::AddAssign<VirtualPointerDelta> for VirtualPointer {
    fn add_assign(&mut self, rhs: VirtualPointerDelta) {
        *self = *self + rhs;
    }
}

impl VirtualPointerDelta {
    pub const fn zero() -> Self {
        Self(0)
    }
    pub const fn with(addr: ADDR_TYPE) -> Self {
        Self(addr)
    }
}

impl VirtualPointer {
    pub const fn with(addr: ADDR_TYPE) -> Self {
        Self(addr)
    }
}

impl Typ {
    pub fn size_bytes(&self) -> usize {
        use ATyp::*;
        use Typ::*;
        match self {
            Address(_) => ADDR_WIDTH.try_into().unwrap(),
            Arith(Bool) => 1,
            Arith(Float(width)) => *width,
            Arith(Int(ityp)) => ityp.width_bytes(),
            Array(inner, sz) => *sz * inner.size_bytes(),
            Void => 0,
            FuncDecl(_, _) => ADDR_WIDTH,
        }
    }

    pub fn size_vptr_delta(&self) -> VirtualPointerDelta {
        VirtualPointerDelta::with(self.size_bytes().try_into().unwrap())
    }
}
