use std::marker::PhantomData;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Idx<T> {
    idx: usize,
    _ph: PhantomData<T>,
}

impl<T> Idx<T> {
    fn get(&self) -> usize {
        self.idx
    }
    fn new(idx: usize) -> Self {
        Self {
            idx,
            _ph: PhantomData,
        }
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OwnedList<T> {
    inner: Vec<T>,
}

impl<T> OwnedList<T> {
    pub fn new() -> Self {
        Self { inner: Vec::new() }
    }

    pub fn add(&mut self, data: T) -> (Idx<T>, &mut T) {
        let idx = self.inner.len();
        self.inner.push(data);
        (Idx::<T>::new(idx), &mut self.inner[idx])
    }

    pub fn get(&self, idx: Idx<T>) -> &T {
        let idx = idx.get();
        &self.inner[idx]
    }

    pub fn get_mut(&mut self, idx: Idx<T>) -> &mut T {
        let idx = idx.get();
        &mut self.inner[idx]
    }
}
